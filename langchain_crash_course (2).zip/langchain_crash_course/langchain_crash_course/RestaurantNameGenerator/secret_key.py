openapi_key = "sk-proj-URqxAps6NH6K0G2v7KCmT3BlbkFJCp7mIZpcwDK1X8cj6W32"
serpapi_key = ""